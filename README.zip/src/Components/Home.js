import React from 'react'
import { useSelector } from 'react-redux'
import Card from './Card'
import { Link } from 'react-router-dom'

const Home = () => {
    const students = useSelector((state)=>state.kids.value)
    return (
        <>
        <Link to="/Addstudent">addStudent</Link>
            {
                students.map((student,index) => {
                    return (
                        <Card id={student.id}
                            firstname={student.firstname}
                            lastname={student.lastname}
                            email={student.email}
                            phno={student.phno}
                            batchno={student.batchno}
                            course={student.course}
                            sNo={index+1}
                        />
                    )
                })
            }
        </>
    )
}
export default Home
