import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addstudent } from '../features/studentSlice'
import { useNavigate } from 'react-router-dom'
import { Link } from 'react-router-dom'
// import Home from './Home'



const AddStudent = () => {
        const[data, setData] = useState({firstname:'',lastname:'',email:'',phno:'',batchno:'',course:''})
        const navigate = useNavigate('')
        const dispatch = useDispatch()
        const student = useSelector((state)=>state.kids.value)
      
     const handleChange = (e)=>{
        const{name,value} = e.target
      
        setData({...data,[name]:value})

     }  
     const dbs =()=>{
      
        dispatch(addstudent({id:student.length+1,...data})) 
        navigate('/')
     } 
  return (
    <>
    <input onChange={handleChange}  name='firstname'placeholder='firstname' value={data.firstname}/>
    <input onChange={handleChange} name='lastname'placeholder='lastname' value={data.lastname}/>
    <input onChange={handleChange} name='email'placeholder='email' value={data.email}/>
    <input onChange={handleChange} name='phno'placeholder='phno' value={data.phno}/>
    <input onChange={handleChange} name='batchno'placeholder='batchno' value={data.batchno}/>
    {/* <input onChange={handleChange} name='course'placeholder='courses' value={data.course}/> */}
    <select name='course' onChange={handleChange} >
      <option value="" selected>select courses</option>
      <option value="fsd">FSD</option>
      <option value="ds">DS</option>
    </select>
    <button onClick={dbs}>addStudent</button>
    <button><Link to="/">previous</Link></button>
    <button><Link to="/updatecontact/:id">Next</Link></button>
    {/* <Home/> */}
    </>
  )
}
export default AddStudent
