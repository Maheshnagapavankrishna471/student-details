import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { updatestudent } from '../features/studentSlice'
import { useNavigate, useParams } from 'react-router-dom'
const EditStudent = () => {
    const{id} = useParams()
    const dispatch = useDispatch()
    const sstudents = useSelector((state)=>state.kids.value)
    const currentStudent = sstudents.find((student)=>student.id==id)
    const navigate = useNavigate()
    const[data, setData] = useState({...currentStudent})

    const handleChange = (e)=>
    {
        const{name,value} = e.target
        console.log('before onchange',data)
        setData({...data,[name]:value})
        console.log('after onchange',data)
    }
    const dbsUpate = ()=>{
        dispatch(updatestudent({id:id,...data}))
        navigate('/')
    }
    return (
        <> 
            <input onChange={handleChange} name='firstname' placeholder='firstname' value={data.firstname} />
            <input onChange={handleChange} name='lastname' placeholder='lastname' value={data.lastname} />
            <input onChange={handleChange} name='email' placeholder='email' value={data.email} />
            <input onChange={handleChange} name='phno' placeholder='phno' value={data.phno} />
            <input onChange={handleChange} name='batchno' placeholder='batchno' value={data.batchno} />
            <input onChange={handleChange} name='course' placeholder='courses' value={data.course} />
            <button onClick={dbsUpate}>editstudent</button>
        </>
    )
}
export default EditStudent
