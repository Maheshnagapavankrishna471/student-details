import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteStudent } from '../features/studentSlice'
import { Link } from 'react-router-dom'

const Card = ({id,firstname,lastname,email,phno,batchno,course,sNo}) => {
    const dispatch = useDispatch()
    const students = useSelector((state) => state.kids.value)
    const deleteM = () => {
        dispatch(deleteStudent({ id: id}))
    }
  return (
    <>
    <h1>{sNo}</h1>
    <h1>{firstname}</h1>
    <h1>{lastname}</h1>
    <h1>{email}</h1>
    <h1>{phno}</h1>
    <h1>{batchno}</h1>
    <h1>{course}</h1>
    <Link to={`/updatecontact/${id}`}><button>editstudent</button></Link>
    <button onClick={deleteM}>DELETE</button>
    </>
  )
}
export default Card
