import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import Card from './Card'
import { Link } from 'react-router-dom'

const Home = () => {
    const students = useSelector((state) => state.kids.value)
    const [search, setSearch] = useState('')
    const [filter, setFilter] = useState('')

    const filteredData = students.filter((val) => {
        let a= val.firstname.toLowerCase().includes(search.toLowerCase())
        return a
    })
     console.log(filteredData,'inside filtered data')

     
    const searchedData = students.filter((val) =>{
        return val.course.toLowerCase().includes(filter.toLowerCase())
    })  
    console.log(searchedData,'heloooooo')  
    
    return (
        <>
            <button><Link to="/Addstudent">addStudent</Link></button>
            <input type='search'
                placeholder='search here....'
                onChange={(e) => {
                    setSearch(e.target.value)
                }}>
            </input>
            <select  name='course'onChange={(e) =>{
                setFilter(e.target.value)
            }}>
                <option value="" selected>FILTER BY COURSES</option>
                <option value="MERN-STACK">MERN STACK</option>
                <option value="DATA-SCIENCE">DATA SCIENCE</option>
            </select>

            {
                filteredData.map((student, index) => {
                    return (
                        <Card id={student.id}
                            firstname={student.firstname}
                            lastname={student.lastname}
                            email={student.email}
                            phno={student.phno}
                            batchno={student.batchno}
                            course={student.course}
                            sNo={index + 1}
                        />
                    )
                })
            }
            {
                searchedData.map((search) =>{
                    return(
                        <>
                            <p id={search.id}
                            course={search.course}/>
                        </>
                    )    
                })
            }
        </>
    )
}
export default Home
