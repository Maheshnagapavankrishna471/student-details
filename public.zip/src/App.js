import React from 'react';
import './App.css';
import AddStudent from './Components/AddStudent';
import EditStudent from './Components/EditStudent';
import {Route,Routes } from 'react-router-dom';
import Home from'./Components/Home'


function App() {
  return (
    <div className="App">
          <h1>STUDENTS DETAILS</h1>
        
          <>
          <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/Addstudent' element={<AddStudent/>}/>
            <Route path='/updatecontact/:id' element={<EditStudent/>}/>
          </Routes>
          </>
          
    </div>
    
  );
}

export default App;
